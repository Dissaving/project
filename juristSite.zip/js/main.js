/*gsap.from(".header__logoName", {duration: 5, opacity:0, /!*scale: 0.3,*!/ fadein: "back"});
gsap.from(".header__dot", { duration: 1, ease: "bounce.out", y: -60 });*/


/*const app = new Vue({
    el: '.page',
    data: {
        windowWidth: 0,
        windowHeight: 0,
        show: false,
        economyDiv: document.getElementById('economyDiv'),
    },

    mounted() {
        this.$nextTick(function () {
            window.addEventListener('resize', this.getWindowWidth);
            window.addEventListener('resize', this.getWindowHeight);

            //Init

            this.getWindowWidth()
            this.getWindowHeight()
        })

    },

    methods: {
        getWindowWidth(event) {
            this.windowWidth = document.documentElement.clientWidth;
        },

        getWindowHeight(event) {
            this.windowHeight = document.documentElement.clientHeight;
        },

        getOffset(el) {
            const rect = el.getBoundingClientRect();
            return {
                left: rect.left + window.scrollX,
                top: rect.top + window.scrollY
            };
        }

    },

    beforeDestroy() {
        window.removeEventListener('resize', this.getWindowWidth);
        window.removeEventListener('resize', this.getWindowHeight);
    },


});*/




