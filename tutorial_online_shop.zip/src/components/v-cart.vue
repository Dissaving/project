<template>

  <div class="v-cart"></div>

</template>

<script>

export default {
  name: "v-cart"
}
</script>

<style >

</style>