let basket = {
    items: [],
    container: null,
    itemsContainer: null,
    shown: false,
    basketTotal: 0,
    basketCount: 0,

    init() {
        this.container = document.querySelector('#basket');
        this.itemsContainer = document.querySelector('#basket-items');
        this._render();
        this._handleActions();
        this._renderBasketTotal();
        this._renderBasketCount();
    },

    _render() {
        let str = '';
        this.items.forEach(item => {
            str += `<div class="dropdown-item header__right_dropdown_man_image_div" data-id="${item.productId}">
    <a class="header__right_cart_man_image_link" href="single_page.html">
        <img style="width: 72px; height: 85px;" class="header__right_cart_man_img" src="${item.productImg}"
         alt="cart_man">
    </a>
    <div class="header__right_dropdown_man_right_main_div">
        <div class="header__right_dropdown_man_right_clothes_name">
            <a class="header__right_dropdown_right_clothes_name_link"
               href="single_page.html"> ${item.productName}</a></div>
        <div class="header__right_dropdown_man_right_stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <div class="header__right_dropdown_man_right_price">
          <span class="drop__count" data-id="${item.productId}">${item.amount}</span>
                            <span class="drop__span">
                            x
                            </span>$${item.productPrice}
        </div>
    </div>
    <button type="button" class="header__right_dropdown_man_right_button fas fa-times-circle" 
    data-id="${item.productId}" data-price="${item.productPrice}" name="remove">
      
    </button>
</div>
<div class="dropdown-divider"></div>`;
        });
        this.itemsContainer.innerHTML = str;
    },

    _handleActions() {
        document.querySelector('#basket-toggler').addEventListener('click', () => {
            this.shown = !this.shown;
            this.container.classList.toggle('invisible');
        });

        this.container.addEventListener('click', ev => {
            console.log(ev.target.name)
            if (ev.target.name === 'remove') {
                this._remove(ev.target.dataset.id, ev.target.dataset.price);
            }
        })
    },

    addToBasket(product) {
        this.basketCount += 1;
        this.basketTotal += product.productPrice;
        let find = this.items.find(el => el.productId === product.productId);
        if (!find) {
            this.items.push(Object.assign(product, {amount: 1}));
        } else {
            find.amount++;
        }
        this._render();
        this._renderBasketTotal();
        this._renderBasketCount();
    },

    _remove(id, price) {
        this.basketCount -= 1;
        this.basketTotal -= price;
        let find = this.items.find(el => el.productId === id);
        if (find.amount > 1) {
            find.amount--;
        } else {
            this.items.splice(this.items.indexOf(find), 1);
        }
        this._render();
        this._renderBasketTotal();
        this._renderBasketCount();
    },

    _renderBasketTotal() {
        document.getElementById('basketTotal').innerHTML = '';
        document.getElementById('basketTotal').append(`$ ${basket.basketTotal} .00`);
    },

    _renderBasketCount() {
        let elemBasketCount = document.createElement("span");
        elemBasketCount.innerHTML = `${this.basketCount}`;
        document.getElementById('basketCountCart').innerHTML = '';
        document.getElementById('basketCountCart').append(elemBasketCount);
    },
};

basket.init();