/* С помощью JSON получаем базу */

let urlIndexPage = "https://raw.githubusercontent.com/Dissaving/git-dis/master/JSON/catalog.json";

let catalog = {
    container: null,
    items: [],
    basket: null,

    init(url) {
        this.container = document.querySelector('#catalog');
        this.getData(url)
            .then(items => {
                this.items = items
            })
            .finally(() => {
                this._render();
                this.basket = basket; //ссылка на объект basket из файла basket.js
                this.handleActions();
            })
    },

    getData(url) {
        return fetch(url) //JSON
            .then(data => data.json()) // JSON >>> Obj/Array
    },

    handleActions() {
        this.container.addEventListener('click', evt => {
            console.log(evt.target)
            console.log(evt.target.name)
            if (evt.target.name === 'addToBasket') {
                let datas = evt.target.dataset;

                let newProd = {
                    productId: datas.id,
                    productPrice: +datas.price,
                    productName: datas.name,
                    productImg: datas.image,
                }

                this.basket.addToBasket(newProd);
            }
        })
    },

    _render() {
        let htmlStr = '';
        this.items.forEach(item => {
            htmlStr += createItemTemplate(item);
        });
        this.container.innerHTML = htmlStr;
    }
}

function createItemTemplate(item) {
    return ` <div class="fi_shadow">
        <div class="fi_block">
            <a class="fi_image_link" href="single_page.html"><img class="fi_image"
                                                                  src="${item.productImg}"
                                                                  alt="fi_image"></a>
            <a class="fi_product" href="single_page.html">${item.productName}</a>
            <div class="fi_price_stars_container">
                <div class="fi_price">$ ${item.productPrice} .00</div>
                <div class="fi_price_stars_5">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
            </div>
            <button class="fi_link" type="button" name="addToBasket" id="${item.productId}"  
            data-id="${item.productId}" 
            data-price="${item.productPrice}" 
            data-name="${item.productName}" 
            data-image="${item.productImg}">
               <!-- <div class="fi_cart_box">-->
                    <img src="../src/assets/img/index/featured_items/fi_shop_cart.svg" alt="fi_shop_cart">
                        <!--<span class="fi_invis_text">-->Add to Cart<!--</span>-->
               <!-- </div>-->
            </button>
        </div>
    </div>`
}

catalog.init(urlIndexPage);


