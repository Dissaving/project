const imgURL = 'https://raw.githubusercontent.com/Dissaving/git-dis/master/';

let NAMES = [
    'MANGO PEOPLE T-SHIRT',
    'BANANA PEOPLE T-SHIRT',
    'STRAWBERRY PEOPLE T-SHIRT',
    'ORANGE PEOPLE T-SHIRT',
    'PUMKIN PEOPLE T-SHIRT',
    'PINEAPPLE PEOPLE T-SHIRT',
    'CUCUMBER PEOPLE T-SHIRT',
    'TOMATO PEOPLE T-SHIRT',
];

let PRICES = [52, 53, 55, 67, 69, 94, 23, 45];

function getArrayOfObjects() {
    let local = [];

    for (let i = 0; i < NAMES.length; i++) {
        local.push({
            productName: NAMES[i],
            productPrice: PRICES[i],
            productImg: `${imgURL}featured_items${i + 1}.jpg`,
            productId: 'prod_' + i
            //rates (звезды)
        })
    }
    return local;
}

let catalog = {
    container: null,
    items: [],
    init() {
        this.container = document.querySelector('#catalog');
        this._fillCatalog();
        this._render();
    },
    _fillCatalog() { //Инкапсуляция (условная для JS)
        this.items = getArrayOfObjects();
    },
    _render() {
        let htmlStr = '';
        this.items.forEach(item => {
            htmlStr += createItemTemplate(item);
        });
        this.container.innerHTML = htmlStr;
    }
}

function createItemTemplate(item) {
    return ` <div class="fi_shadow">
        <div class="fi_block">
            <a class="fi_image_link" href="single_page.html"><img class="fi_image"
                                                                  src="${item.productImg}"
                                                                  alt="fi_image"></a>
            <a class="fi_product" href="single_page.html">${item.productName}</a>
            <div class="fi_price_stars_container">
                <div class="fi_price">$ ${item.productPrice} .00</div>
                <div class="fi_price_stars_5">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
            </div>
            <a class="fi_link" href="shopping_cart.html">
                <div class="fi_cart_box">
                    <img src="img/index/featured_items/fi_shop_cart.svg" alt="fi_shop_cart">
                        <span class="fi_invis_text">Add to Cart</span>
                </div>
            </a>
        </div>
    </div>`
}

catalog.init();